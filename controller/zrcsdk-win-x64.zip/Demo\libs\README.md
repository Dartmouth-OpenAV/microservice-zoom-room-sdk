## You will need this folder, place the libs here.

```
libs/
|── libZRCSdk.so # The ZRCSDK lib
|── libuv.a      # Demo app uses libuv
```